const express = require('express');
const { createServer } = require('http');
const { WebSocketServer } = require('ws');
const path = require('path');

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.use(express.static('.'));
app.use(express.json());

// Store rooms and WebSocket connections
const rooms = new Map();
const connections = new Map();

wss.on('connection', (ws) => {
  let playerId = null;

  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString());
      const { type, data: msgData } = message;

      switch (type) {
        case 'CONNECT':
          playerId = msgData.playerId;
          connections.set(playerId, ws);
          ws.send(JSON.stringify({ type: 'CONNECTED', data: { playerId } }));
          break;
        case 'CREATE_ROOM':
          handleCreateRoom(ws, msgData);
          break;
        case 'JOIN_ROOM':
          handleJoinRoom(ws, msgData);
          break;
        case 'START_GAME':
          handleStartGame(ws, msgData);
          break;
        case 'PLAY_CARD':
          handlePlayCard(ws, msgData);
          break;
        case 'QUICK_MATCH':
          handleQuickMatch(ws, msgData);
          break;
        case 'LEAVE_ROOM':
          handleLeaveRoom(ws, msgData);
          break;
        case 'CREATE_WITH_COMPUTERS':
          handleCreateWithComputers(ws, msgData);
          break;
        case 'SEND_CHAT':
          handleChatMessage(ws, msgData);
          break;
        default:
          ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Unknown message type' } }));
      }
    } catch (error) {
      console.error('WebSocket message error:', error);
      ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Invalid message format' } }));
    }
  });

  ws.on('close', () => {
    if (playerId) {
      connections.delete(playerId);
      for (const [roomCode, room] of rooms) {
        const playerIndex = room.players.findIndex((p) => p.id === playerId);
        if (playerIndex !== -1) {
          room.players[playerIndex].isConnected = false;
          broadcastToRoom(roomCode, 'PLAYER_DISCONNECTED', { playerId });
          if (room.gameState?.currentPlayer === playerId) {
            room.gameState.currentPlayer = getNextPlayerWithCards(room.gameState, playerId);
            broadcastToRoom(roomCode, 'CARD_PLAYED', { gameState: room.gameState, skippedPlayer: playerId });
            if (room.gameState.players.find((p) => p.id === room.gameState.currentPlayer)?.isComputer) {
              setTimeout(() => handleComputerPlay(roomCode), 1500);
            }
          }
          break;
        }
      }
    }
  });
});

// Create a new room
function handleCreateRoom(ws, data) {
  const roomCode = generateRoomCode();
  const player = {
    id: data.playerId,
    name: data.playerName,
    cards: [],
    cardCount: 0,
    isHost: true,
    isConnected: true,
    isComputer: false,
  };

  const room = {
    code: roomCode,
    hostId: data.playerId,
    players: [player],
    maxPlayers: 4,
    gameState: null,
  };

  rooms.set(roomCode, room);
  ws.send(JSON.stringify({ type: 'ROOM_CREATED', data: { room } }));
}

// Join an existing room
function handleJoinRoom(ws, data) {
  const room = rooms.get(data.roomCode);
  if (!room) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Room not found' } }));
    return;
  }

  if (room.players.length >= room.maxPlayers) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Room is full' } }));
    return;
  }

  if (room.gameState?.isStarted) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Game already started' } }));
    return;
  }

  const player = {
    id: data.playerId,
    name: data.playerName,
    cards: [],
    cardCount: 0,
    isHost: false,
    isConnected: true,
    isComputer: false,
  };

  room.players.push(player);
  broadcastToRoom(data.roomCode, 'PLAYER_JOINED', { room, player });
}

// Start the game
function handleStartGame(ws, data) {
  const room = rooms.get(data.roomCode);
  if (!room || room.hostId !== data.playerId) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Only host can start game' } }));
    return;
  }

  if (room.players.length < 2) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Need at least 2 players' } }));
    return;
  }

  // Add computer players if requested
  if (data.addComputers) {
    const computerCount = room.maxPlayers - room.players.length;
    for (let i = 0; i < computerCount; i++) {
      const computerPlayer = {
        id: `computer_${i + 1}`,
        name: `Computer ${i + 1}`,
        cards: [],
        cardCount: 0,
        isHost: false,
        isConnected: true,
        isComputer: true,
      };
      room.players.push(computerPlayer);
    }
  }

  const deck = generateDeck();
  const cardsPerPlayer = Math.floor(deck.length / room.players.length);

  // Deal cards to players
  room.players.forEach((player, index) => {
    player.cards = deck.slice(index * cardsPerPlayer, (index + 1) * cardsPerPlayer);
    player.cardCount = player.cards.length;
  });

  // Rule 1: Find player with Ace of Spades to start
  let startingPlayer = null;
  for (const player of room.players) {
    if (player.cards.some((card) => card.suit === 'spades' && card.value === 'A')) {
      startingPlayer = player;
      break;
    }
  }
  if (!startingPlayer) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Ace of Spades not found' } }));
    return;
  }

  room.gameState = {
    isStarted: true,
    currentPlayer: startingPlayer.id,
    round: 1,
    totalRounds: cardsPerPlayer,
    leadSuit: null,
    currentTrick: { cards: [], leadSuit: null, winner: null },
    completedTricks: [],
    players: room.players,
    isFinished: false,
    bhabi: null,
    mustPlayAceOfSpades: true,
    isFirstRound: true,
  };

  broadcastToRoom(data.roomCode, 'GAME_STARTED', { gameState: room.gameState });

  if (startingPlayer.isComputer) {
    setTimeout(() => handleComputerPlay(data.roomCode), 1500);
  }
}

// Handle a player playing a card
function handlePlayCard(ws, data) {
  const room = rooms.get(data.roomCode);
  if (!room || !room.gameState) {
    ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Game not found' } }));
    return;
  }

  const gameState = room.gameState;
  if (gameState.currentPlayer !== data.playerId) {
    ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Not your turn' } }));
    return;
  }

  const player = gameState.players.find((p) => p.id === data.playerId);
  if (!player || player.cardCount === 0) {
    ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Player not found or no cards' } }));
    return;
  }

  const cardIndex = player.cards.findIndex((c) => c.id === data.cardId);
  if (cardIndex === -1) {
    ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Card not in hand' } }));
    return;
  }

  const playedCard = player.cards[cardIndex];

  // Rule 1: First move must be Ace of Spades
  if (gameState.mustPlayAceOfSpades) {
    if (playedCard.suit !== 'spades' || playedCard.value !== 'A') {
      ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Must play Ace of Spades first!' } }));
      return;
    }
    gameState.mustPlayAceOfSpades = false;
    gameState.leadSuit = 'spades';
    gameState.currentTrick.leadSuit = 'spades';
  }

  // Rule 2 & 4: Thulla logic
  let isThulla = false;
  if (gameState.leadSuit && playedCard.suit !== gameState.leadSuit) {
    if (player.cards.some((c) => c.suit === gameState.leadSuit)) {
      // Player has lead suit but played different suit (invalid)
      ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Must follow suit if you have it!' } }));
      return;
    } else if (!gameState.isFirstRound) {
      // Rule 2: No Thulla in first round; otherwise, declare Thulla
      isThulla = true;
      console.log(`${player.name} declared Thulla - no ${gameState.leadSuit} cards`);
    }
  }

  // Remove card from player's hand
  player.cards.splice(cardIndex, 1);
  player.cardCount = player.cards.length;

  // Add card to current trick
  playedCard.playedBy = data.playerId;
  playedCard.isThulla = isThulla;
  gameState.currentTrick.cards.push(playedCard);

  // Set lead suit if first card of trick
  if (!gameState.currentTrick.leadSuit) {
    gameState.currentTrick.leadSuit = playedCard.suit;
    gameState.leadSuit = playedCard.suit;
  }

  // Rule 4: Check if trick is complete or Thulla declared
  const activePlayers = gameState.players.filter((p) => p.cardCount > 0);
  const trickComplete = gameState.currentTrick.cards.length === activePlayers.length;

  if (trickComplete || isThulla) {
    // Rule 4 & 5: Find player with highest card of lead suit
    const leadSuitCards = gameState.currentTrick.cards.filter((c) => c.suit === gameState.currentTrick.leadSuit);
    if (leadSuitCards.length === 0) {
      console.error('No lead suit cards in trick:', gameState.currentTrick);
      ws?.send(JSON.stringify({ type: 'ERROR', data: { message: 'Invalid trick state' } }));
      return;
    }

    let highestCard = leadSuitCards[0];
    let highestValue = getCardValue(highestCard);

    for (const card of leadSuitCards) {
      const cardValue = getCardValue(card);
      if (cardValue > highestValue) {
        highestValue = cardValue;
        highestCard = card;
      }
    }

    const highestCardPlayer = gameState.players.find((p) => p.id === highestCard.playedBy);
    if (!highestCardPlayer) {
      console.error('Highest card player not found:', highestCard.playedBy);
      return;
    }

    gameState.currentTrick.winner = highestCard.playedBy;
    gameState.lastTrickWinner = highestCard.playedBy;

    if (isThulla) {
      // Rule 5: If Thulla, assign cards to highest card player
      highestCardPlayer.cards.push(...gameState.currentTrick.cards);
      highestCardPlayer.cardCount = highestCardPlayer.cards.length;
      console.log(`${highestCardPlayer.name} gets ${gameState.currentTrick.cards.length} cards due to Thulla (highest: ${highestCard.value} of ${highestCard.suit})`);

      const thullaPlayer = gameState.players.find((p) => p.id === data.playerId);
      broadcastToRoom(data.roomCode, 'THULLA_PENALTY', {
        gameState,
        winnerPlayer: highestCardPlayer.name,
        cardsCount: gameState.currentTrick.cards.length,
        thullaPlayer: thullaPlayer.name,
      });
    } else if (trickComplete) {
      // Rule 5: If no Thulla, discard cards permanently
      console.log(`Trick completed without Thulla; ${gameState.currentTrick.cards.length} cards discarded`);
      broadcastToRoom(data.roomCode, 'TRICK_COMPLETE_DELAY', { gameState });
    }

    // Rule 3: Reset trick and set next player (highest card player)
    const resetTrick = () => {
      gameState.completedTricks.push({ ...gameState.currentTrick });
      gameState.currentTrick = { cards: [], leadSuit: null, winner: null };
      gameState.leadSuit = null;
      gameState.currentPlayer = gameState.lastTrickWinner; // Rule 3: Highest card leads
      gameState.round++;
      gameState.isFirstRound = false; // Rule 2: First round completed

      // Rule 8: Ensure winner has cards; otherwise, find next player
      const winnerPlayer = gameState.players.find((p) => p.id === gameState.currentPlayer);
      if (!winnerPlayer || winnerPlayer.cardCount === 0) {
        gameState.currentPlayer = getNextPlayerWithCards(gameState, gameState.currentPlayer);
      }

      broadcastToRoom(data.roomCode, 'NEXT_TRICK_READY', { gameState });

      const nextPlayer = gameState.players.find((p) => p.id === gameState.currentPlayer);
      if (nextPlayer?.isComputer) {
        setTimeout(() => handleComputerPlay(data.roomCode), 1500);
      }
    };

    setTimeout(resetTrick, trickComplete ? 2000 : 1000);
  } else {
    // Move to next player in same trick
    gameState.currentPlayer = getNextPlayerWithCards(gameState, data.playerId);
    broadcastToRoom(data.roomCode, 'CARD_PLAYED', { gameState, playedCard, playerId: data.playerId, isThulla });
  }

  // Rule 8: Check if game has ended
  if (checkGameEnd(gameState, data.roomCode)) {
    return;
  }

  // Handle next computer player
  const nextPlayer = gameState.players.find((p) => p.id === gameState.currentPlayer);
  if (nextPlayer?.isComputer && !trickComplete && !isThulla) {
    setTimeout(() => handleComputerPlay(data.roomCode), 1500);
  }
}

// Rule 8: Check if game has ended and declare Bhabi
function checkGameEnd(gameState, roomCode) {
  const playersWithCards = gameState.players.filter((p) => p.cardCount > 0);

  if (playersWithCards.length <= 1) {
    gameState.isFinished = true;
    if (playersWithCards.length === 1) {
      gameState.bhabi = playersWithCards[0].id;
      console.log(`Game Over! ${playersWithCards[0].name} is the Bhabi (${playersWithCards[0].cardCount} cards left)`);
    } else {
      console.log('Game Over! No Bhabi (all players out)');
      gameState.bhabi = null;
    }
    broadcastToRoom(roomCode, 'GAME_FINISHED', { gameState });
    return true;
  }
  return false;
}

// Rule 8: Get next player with cards
function getNextPlayerWithCards(gameState, currentPlayerId) {
  const currentIndex = gameState.players.findIndex((p) => p.id === currentPlayerId);
  let nextIndex = currentIndex;
  let attempts = 0;

  do {
    nextIndex = (nextIndex + 1) % gameState.players.length;
    attempts++;
    if (attempts >= gameState.players.length) {
      const playerWithCards = gameState.players.find((p) => p.cardCount > 0);
      return playerWithCards ? playerWithCards.id : currentPlayerId;
    }
  } while (gameState.players[nextIndex].cardCount === 0);

  return gameState.players[nextIndex].id;
}

// Handle quick match
function handleQuickMatch(ws, data) {
  let targetRoom = null;
  for (const room of rooms.values()) {
    if (room.players.length > 0 && room.players.length < room.maxPlayers && !room.gameState) {
      targetRoom = room;
      break;
    }
  }

  if (!targetRoom) {
    const roomCode = 'QM' + generateRoomCode();
    targetRoom = {
      code: roomCode,
      hostId: data.playerId,
      players: [],
      maxPlayers: 4,
      gameState: null,
    };
    rooms.set(roomCode, targetRoom);
  }

  const player = {
    id: data.playerId,
    name: data.playerName,
    cards: [],
    cardCount: 0,
    isHost: targetRoom.players.length === 0,
    isConnected: true,
    isComputer: false,
  };

  targetRoom.players.push(player);
  ws.send(JSON.stringify({ type: 'ROOM_CREATED', data: { room: targetRoom } }));

  if (targetRoom.players.length >= 3) {
    setTimeout(() => {
      handleStartGame(ws, { roomCode: targetRoom.code, playerId: targetRoom.hostId, addComputers: true });
    }, 2000);
  }
}

// Handle player leaving a room
function handleLeaveRoom(ws, data) {
  const room = rooms.get(data.roomCode);
  if (!room) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Room not found' } }));
    return;
  }

  const playerIndex = room.players.findIndex((p) => p.id === data.playerId);
  if (playerIndex === -1) {
    ws.send(JSON.stringify({ type: 'ERROR', data: { message: 'Player not found' } }));
    return;
  }

  room.players.splice(playerIndex, 1);

  if (room.players.length === 0) {
    rooms.delete(data.roomCode);
  } else {
    if (room.hostId === data.playerId && room.players.length > 0) {
      room.hostId = room.players[0].id;
      room.players[0].isHost = true;
    }
    broadcastToRoom(data.roomCode, 'PLAYER_LEFT', { room, playerId: data.playerId });
  }

  ws.send(JSON.stringify({ type: 'LEFT_ROOM', data: { roomCode: data.roomCode } }));
}

// Handle chat messages
function handleChatMessage(ws, data) {
  const room = rooms.get(data.roomCode);
  if (!room) return;

  const player = room.players.find((p) => p.id === data.playerId);
  if (!player) return;

  const chatMessage = {
    playerId: data.playerId,
    playerName: player.name,
    message: data.message,
    timestamp: new Date().toISOString(),
    isComputer: player.isComputer || false,
  };

  broadcastToRoom(data.roomCode, 'CHAT_MESSAGE', { chatMessage });
}

// Create room with computer players
function handleCreateWithComputers(ws, data) {
  const roomCode = generateRoomCode();
  const player = {
    id: data.playerId,
    name: data.playerName,
    cards: [],
    cardCount: 0,
    isHost: true,
    isConnected: true,
    isComputer: false,
  };

  const room = {
    code: roomCode,
    hostId: data.playerId,
    players: [player],
    maxPlayers: 4,
    gameState: null,
    withComputers: true,
  };

  for (let i = 1; i <= 3; i++) {
    const computerPlayer = {
      id: `computer_${i}`,
      name: `Computer ${i}`,
      cards: [],
      cardCount: 0,
      isHost: false,
      isConnected: true,
      isComputer: true,
    };
    room.players.push(computerPlayer);
  }

  rooms.set(roomCode, room);
  ws.send(JSON.stringify({ type: 'ROOM_CREATED', data: { room } }));
}

// Broadcast message to all players in a room
function broadcastToRoom(roomCode, type, data) {
  const room = rooms.get(roomCode);
  if (!room) return;

  room.players.forEach((player) => {
    const connection = connections.get(player.id);
    if (connection && connection.readyState === 1) {
      connection.send(JSON.stringify({ type, data }));
    }
  });
}

// Generate a random room code
function generateRoomCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Generate and shuffle a deck
function generateDeck() {
  const suits = ['spades', 'hearts', 'diamonds', 'clubs'];
  const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  const deck = [];

  suits.forEach((suit) => {
    values.forEach((value) => {
      deck.push({
        id: `${value.toLowerCase()}_${suit[0]}`,
        suit,
        value,
      });
    });
  });

  // Shuffle deck
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return deck;
}

// Get numerical value of a card
function getCardValue(card) {
  const values = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 8, '8': 8, '9': 9, '10': 10,
    'J': 11, 'Q': 12, 'K': 13, 'A': 14,
  };
  return values[card.value] || 0;
}

// Rule 7: Computer player AI
function handleComputerPlay(roomCode) {
  const room = rooms.get(roomCode);
  if (!room || !room.gameState) return;

  const gameState = room.gameState;
  const computerPlayer = gameState.players.find((p) => p.id === gameState.currentPlayer && p.isComputer);

  if (!computerPlayer || computerPlayer.cardCount === 0) {
    console.log(`Computer ${computerPlayer?.name || 'unknown'} has no cards, skipping`);
    gameState.currentPlayer = getNextPlayerWithCards(gameState, gameState.currentPlayer);
    broadcastToRoom(roomCode, 'CARD_PLAYED', { gameState, skippedPlayer: computerPlayer?.name });

    const nextPlayer = gameState.players.find((p) => p.id === gameState.currentPlayer);
    if (nextPlayer?.isComputer) {
      setTimeout(() => handleComputerPlay(roomCode), 1500);
    }
    return;
  }

  let cardToPlay = null;

  if (gameState.mustPlayAceOfSpades) {
    // Rule 1: Must play Ace of Spades
    cardToPlay = computerPlayer.cards.find((c) => c.suit === 'spades' && c.value === 'A');
  } else if (gameState.currentTrick.leadSuit) {
    const sameSuitCards = computerPlayer.cards.filter((c) => c.suit === gameState.currentTrick.leadSuit);
    if (sameSuitCards.length > 0) {
      // Rule 7: Strategic play based on remaining players
      const remainingPlayers = gameState.players.filter(
        (p) => p.cardCount > 0 && p.id !== computerPlayer.id && !gameState.currentTrick.cards.some((tc) => tc.playedBy === p.id)
      );

      const trickCards = gameState.currentTrick.cards.filter((c) => c.suit === gameState.currentTrick.leadSuit);
      const highestTrickValue = trickCards.length > 0 ? Math.max(...trickCards.map((c) => getCardValue(c))) : 0;

      if (remainingPlayers.length >= 2 && Math.random() < 0.8) {
        // Play low card to avoid Thulla penalty
        cardToPlay = sameSuitCards.reduce((lowest, card) => (getCardValue(card) < getCardValue(lowest) ? card : lowest));
      } else if (highestTrickValue > 0) {
        // Try to beat highest card if no Thulla risk
        const higherCards = sameSuitCards.filter((c) => getCardValue(c) > highestTrickValue);
        cardToPlay = higherCards.length > 0
          ? higherCards.reduce((highest, card) => (getCardValue(card) < getCardValue(highest) ? card : highest)) // Lowest of higher cards
          : sameSuitCards.reduce((lowest, card) => (getCardValue(card) < getCardValue(lowest) ? card : lowest)); // Fallback to lowest
      } else {
        cardToPlay = sameSuitCards[0];
      }
    } else {
      // Rule 4: Play Thulla with lowest card (if not first round)
      cardToPlay = computerPlayer.cards.reduce((lowest, card) => (getCardValue(card) < getCardValue(lowest) ? card : lowest));
    }
  } else {
    // Leading: Play lowest card of strongest suit
    const suitCounts = { spades: 0, hearts: 0, diamonds: 0, clubs: 0 };
    computerPlayer.cards.forEach((c) => suitCounts[c.suit]++);
    const strongestSuit = Object.keys(suitCounts).reduce((a, b) => (suitCounts[a] > suitCounts[b] ? a : b));
    const suitCards = computerPlayer.cards.filter((c) => c.suit === strongestSuit);
    cardToPlay = suitCards.reduce((lowest, card) => (getCardValue(card) < getCardValue(lowest) ? card : lowest));
  }

  if (cardToPlay) {
    // Random chat message for computer
    if (Math.random() < 0.15) {
      const computerMessages = ['Playing my card', 'Here’s my move', 'Let’s see...', 'Your turn', 'Take this!'];
      const randomMessage = computerMessages[Math.floor(Math.random() * computerMessages.length)];
      handleChatMessage(null, {
        playerId: computerPlayer.id,
        roomCode: roomCode,
        message: randomMessage,
      });
    }

    const data = {
      playerId: computerPlayer.id,
      roomCode: roomCode,
      cardId: cardToPlay.id,
    };

    setTimeout(() => {
      handlePlayCard(null, data);
    }, 1000);
  } else {
    console.error(`Computer ${computerPlayer.name} couldn't find a card to play`);
    gameState.currentPlayer = getNextPlayerWithCards(gameState, gameState.currentPlayer);
    broadcastToRoom(roomCode, 'CARD_PLAYED', { gameState, skippedPlayer: computerPlayer.name });
  }
}

// Serve the game HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'game.html'));
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Bhabi Thulla Server running on port ${PORT}`);
  console.log(`http://localhost:${PORT}`);
});